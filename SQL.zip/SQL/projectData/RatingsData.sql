use ProjectMahoraga

INSERT INTO rating (uname, aniid, Rating)
VALUES 
('naruto', 1, 5),
('sasuke', 1, 4),
('goku', 3, 5),
('luffy', 2, 4),
('vegeta', 3, 4),
('ichigo', 6, 5),
('eren', 4, 5),
('sakura', 21, 3),
('levi', 22, 5),
('hinata', 10, 4),
('gaara', 4, 4),
('gohan', 3, 5),
('narancia', 14, 4),
('sanji', 2, 4),
('yusuke', 17, 5);

select * from rating