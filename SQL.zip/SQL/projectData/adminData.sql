use ProjectMahoraga
insert into [Admin] values('_Waleed_')
insert into [Admin] values('_Arooba_')
insert into [Admin] values('_Armeen_')

select * from [Admin]